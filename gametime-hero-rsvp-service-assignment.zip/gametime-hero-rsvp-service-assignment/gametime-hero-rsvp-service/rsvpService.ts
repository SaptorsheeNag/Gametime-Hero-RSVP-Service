import { RsvpEntry, Player, RsvpStatus, Logger } from "./interfaces";

export class RsvpService {
  private rsvps: Map<string, RsvpEntry> = new Map();

  constructor(private logger: Logger) {}

  public addOrUpdateRsvp(player: Player, status: RsvpStatus): void {
    this.rsvps.set(player.id, { player, status });
    this.logger.log(`RSVP updated: ${player.name} - ${status}`);
  }

  public getConfirmedAttendees(): string[] {
    return Array.from(this.rsvps.values())
      .filter(entry => entry.status === "Yes")
      .map(entry => entry.player.id);
  }

  public countRsvps(): { total: number; confirmed: number; declined: number } {
    let confirmed = 0, declined = 0;
    for (const entry of this.rsvps.values()) {
      if (entry.status === "Yes") confirmed++;
      else if (entry.status === "No") declined++;
    }
    return { total: this.rsvps.size, confirmed, declined };
  }
}