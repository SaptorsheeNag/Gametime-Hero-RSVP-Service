import { Logger } from "./interfaces";

export class ConsoleLogger implements Logger {
  log(message: string): void {
    console.log("[LOG]:", message);
  }
}
