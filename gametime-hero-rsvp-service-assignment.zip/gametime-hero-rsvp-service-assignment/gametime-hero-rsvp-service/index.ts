import { RsvpService } from "./rsvpService";
import { ConsoleLogger } from "./logger";
import { Player, RsvpEntry, RsvpStatus } from "./interfaces";
import * as readline from "readline";

const logger = new ConsoleLogger();
const rsvpService = new RsvpService(logger);

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function askQuestion(query: string): Promise<string> {
  return new Promise(resolve => rl.question(query, resolve));
}

async function main() {
  console.log("Enter player details (enter 'done' to finish):");

  while (true) {
    const id = await askQuestion("Player ID: ");
    if (id.toLowerCase() === "done") break;

    const name = await askQuestion("Player Name: ");
    const status = await askQuestion("RSVP Status (Yes/No/Maybe): ");

    if (!["Yes", "No", "Maybe"].includes(status)) {
      console.log("Invalid status. Please enter Yes, No, or Maybe.");
      continue;
    }

    rsvpService.addOrUpdateRsvp({ id, name }, status as RsvpStatus);
    console.log("RSVP Added.\n");
  }

  console.log("\nConfirmed attendees:", rsvpService.getConfirmedAttendees());
  console.log("RSVP counts:", rsvpService.countRsvps());

  rl.close();
}

main();